import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'custom-search-filter-example';
  searchedKeyword: string;
  filterResultDataSet=[];
  ngOnInit(){
    this.setData();
  }

  getData(){
    return fetch('https://api.publicapis.org/categories').then(res => res.json()).then((response) => {
      return response;
    });
  }

  async setData(){
    let data = await this.getData();
   for (let i = 0; i < data.length; i++) {
     this.filterResultDataSet.push({categories:data[i]})
   }
    console.log(this.filterResultDataSet)
  }
}
