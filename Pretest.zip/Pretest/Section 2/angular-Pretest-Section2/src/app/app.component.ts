import { Component, OnInit } from '@angular/core';
import { Pipe } from '@angular/core';
@Pipe({ name: 'round' })

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'angular-Pretest-Section2';
  inputNumber: any;
  dropDown: any;
  inputDropDown: any;
  isTrueorFalse: any;
  constructor() { }

  ngOnInit() {
    this.setData()
  }

  setData() {
    this.dropDown = ["", "IsPrime", "isFibonacci"]
  }

  onChangeNumber($event) {
    console.log($event)
    if ($event < 0) {
      this.inputNumber = 1;
    }
    this.inputNumber = this.transform(this.inputNumber);
    this.onChangeDropDown()
  }

  transform(num) {
    return Math.round(num);
  }

  onChangeDropDown() {
      if (this.inputDropDown === "IsPrime") {
        this.isTrueorFalse = this.isPrime(this.inputNumber)
      } else if (this.inputDropDown === "isFibonacci") {
        this.isTrueorFalse = this.isFibonacci(this.inputNumber)
      }
  }

  isPrime(num) {
    var sqrt = Math.sqrt(num);
    for (var i = 2; i <= sqrt; i++)
      if (num % i === 0) return false;
    return true;
  }

  isFibonacci(num) {
    if (this.isPerfectSquare(5 * (num * num) - 4) || this.isPerfectSquare(5 * (num * num) + 4)) {
      return true;
    } else { return false; }
  }

  isPerfectSquare(x) {
    let s = Math.sqrt(x);
    return (s * s == x);
  }
}
